const questions = [
  { question: "Who won the 2023 AFL Grand Final?", answer: "Collingwood" },
  { question: "Which team finished last in 2023?", answer: "West Coast" }
];