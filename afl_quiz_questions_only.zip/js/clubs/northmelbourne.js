const questions = [
  { question: "Who is the current captain of North Melbourne?", answer: "Sample" },
  { question: "When did North Melbourne last win a premiership?", answer: "Sample" }
];