const questions = [
  { question: "Who is the current captain of Geelong?", answer: "Sample" },
  { question: "When did Geelong last win a premiership?", answer: "Sample" }
];