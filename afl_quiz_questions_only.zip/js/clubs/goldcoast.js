const questions = [
  { question: "Who is the current captain of Gold Coast?", answer: "Sample" },
  { question: "When did Gold Coast last win a premiership?", answer: "Sample" }
];