const questions = [
  { question: "Who is the current captain of Carlton?", answer: "Sample" },
  { question: "When did Carlton last win a premiership?", answer: "Sample" }
];