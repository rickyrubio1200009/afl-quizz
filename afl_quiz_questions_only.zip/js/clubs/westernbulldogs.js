const questions = [
  { question: "Who is the current captain of Western Bulldogs?", answer: "Sample" },
  { question: "When did Western Bulldogs last win a premiership?", answer: "Sample" }
];