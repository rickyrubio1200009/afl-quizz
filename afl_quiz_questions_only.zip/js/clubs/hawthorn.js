const questions = [
  { question: "Who is the current captain of Hawthorn?", answer: "Sample" },
  { question: "When did Hawthorn last win a premiership?", answer: "Sample" }
];