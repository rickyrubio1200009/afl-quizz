const questions = [
  { question: "Who is the current captain of West Coast?", answer: "Sample" },
  { question: "When did West Coast last win a premiership?", answer: "Sample" }
];