const questions = [
  { question: "Who is the current captain of Collingwood?", answer: "Sample" },
  { question: "When did Collingwood last win a premiership?", answer: "Sample" }
];