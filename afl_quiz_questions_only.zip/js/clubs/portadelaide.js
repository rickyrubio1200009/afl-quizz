const questions = [
  { question: "Who is the current captain of Port Adelaide?", answer: "Sample" },
  { question: "When did Port Adelaide last win a premiership?", answer: "Sample" }
];