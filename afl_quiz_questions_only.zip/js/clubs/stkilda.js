const questions = [
  { question: "Who is the current captain of St Kilda?", answer: "Sample" },
  { question: "When did St Kilda last win a premiership?", answer: "Sample" }
];