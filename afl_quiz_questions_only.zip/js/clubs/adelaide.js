const questions = [
  { question: "Who is the current captain of Adelaide?", answer: "Sample" },
  { question: "When did Adelaide last win a premiership?", answer: "Sample" }
];