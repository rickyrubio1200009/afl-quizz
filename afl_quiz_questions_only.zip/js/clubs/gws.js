const questions = [
  { question: "Who is the current captain of GWS?", answer: "Sample" },
  { question: "When did GWS last win a premiership?", answer: "Sample" }
];