const questions = [
  { question: "Who is the current captain of Sydney?", answer: "Sample" },
  { question: "When did Sydney last win a premiership?", answer: "Sample" }
];