const questions = [
  { question: "Who is the current captain of Melbourne?", answer: "Sample" },
  { question: "When did Melbourne last win a premiership?", answer: "Sample" }
];