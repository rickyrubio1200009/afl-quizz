const questions = [
  { question: "Who is the current captain of Richmond?", answer: "Sample" },
  { question: "When did Richmond last win a premiership?", answer: "Sample" }
];