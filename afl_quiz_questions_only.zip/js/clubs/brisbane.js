const questions = [
  { question: "Who is the current captain of Brisbane?", answer: "Sample" },
  { question: "When did Brisbane last win a premiership?", answer: "Sample" }
];