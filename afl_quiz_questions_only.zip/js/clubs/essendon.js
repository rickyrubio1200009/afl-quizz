const questions = [
  { question: "Who is the current captain of Essendon?", answer: "Sample" },
  { question: "When did Essendon last win a premiership?", answer: "Sample" }
];