const questions = [
  { question: "Who is the current captain of Fremantle?", answer: "Sample" },
  { question: "When did Fremantle last win a premiership?", answer: "Sample" }
];