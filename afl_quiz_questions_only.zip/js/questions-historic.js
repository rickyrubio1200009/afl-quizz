const questions = [
  { question: "Who won the 1997 AFL Premiership?", answer: "Adelaide" },
  { question: "When did Brisbane last win a Grand Final?", answer: "2003" }
];